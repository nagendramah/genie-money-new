class ProofsModel {
  String name, title, subtitle;

  ProofsModel(this.name, this.title, this.subtitle);
}

