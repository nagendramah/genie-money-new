class AppHistoryModel {
  String code, mobile_no, imei, date_created, date_expire, validity, name;

  AppHistoryModel(this.code, this.mobile_no, this.imei, this.date_created,
      this.date_expire, this.validity, this.name);
}