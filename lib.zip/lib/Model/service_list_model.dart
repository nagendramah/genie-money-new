class ServiceModel {
  String name, image;
  double rating;

  ServiceModel(this.name, this.image, this.rating);
}