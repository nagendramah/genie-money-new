class PreApprovedOffers {
  String icon, title, company_image, big_title, point_1, point_2, point_3;

  PreApprovedOffers(
      this.icon,
      this.title,
      this.company_image,
      this.big_title,
      this.point_1,
      this.point_2,
      this.point_3);
}