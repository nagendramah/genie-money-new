class IconModel {
  late String  name, image;

  IconModel({ required this.name, required this.image});
}