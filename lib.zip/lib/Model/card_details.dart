class CardDetails {
  String bank_name, card_first_number, card_last_number, customer_name;

  CardDetails(this.bank_name, this.card_first_number, this.card_last_number, this.customer_name);
}