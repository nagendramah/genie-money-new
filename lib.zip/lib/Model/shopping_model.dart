class ShoppingModel {
  String name, offer, image;

  ShoppingModel(this.name, this.offer, this.image);
}