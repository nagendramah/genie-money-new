class PayeeDetailsModel {
  String name;

  PayeeDetailsModel(this.name);
}