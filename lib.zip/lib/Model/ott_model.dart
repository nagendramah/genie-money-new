class OTTModel {
  String id, name, image, packageName;

  OTTModel(this.id, this.name, this.image, this.packageName);
}