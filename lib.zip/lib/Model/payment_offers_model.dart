import 'package:flutter/cupertino.dart';

class PaymentModel {
  String name, offer;
  Icon icon;

  PaymentModel(this.name, this.offer, this.icon);
}