class OnBoardScreenList {
  String image, title, subtitle;

  OnBoardScreenList(this.image, this.title, this.subtitle);
}