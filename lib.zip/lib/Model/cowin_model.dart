class CowinModel{
  final String optionName;
  final String processName;
  final String imagePath;
  final String url;

  CowinModel(this.optionName, this.processName,this.imagePath,this.url);
}