
import '../../Model/utility/OperatorModel.dart';

class OperatorListRepo{
  Future<OperatorModel?> getOperatorList()async{}
}

class DoRechargeRepo{
  //Future<>
}