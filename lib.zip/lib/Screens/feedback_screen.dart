import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../Model/IconModel.dart';
import '../Model/feedBackResponseModel.dart';
import '../data/remote/network/NetworkApiServiceNewVendor.dart';
import '../utils/constants.dart';

class FeedbackScreen extends StatefulWidget {
  FeedbackScreen({Key? key}) : super(key: key);

  @override
  State<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  final TextEditingController feedbackController = TextEditingController();

  TextEditingController dateController = TextEditingController();

  TextEditingController descriptionController = TextEditingController();

  TextEditingController titleController = TextEditingController();
  late String user;

  @override
  void initState() {
    getuserid();

    super.initState();

  }

  /*
  late List<IconModel> Iconss;
*/
  var dateTime = DateFormat('yyyy-MM-dd kk:mm:ss').format(DateTime.now());

  List<Widget> icons = [
    Image.asset('images/website.png'),
    Image.asset('images/Email.png'),
    Image.asset('images/Facebook-256.png'),
    Image.asset('images/Twitter-Bird-256.png'),
    Image.asset("images/Instagram-256.png"),
    Image.asset('images/YouTube1-256.png'),
    Image.asset('images/LinkedIn.png'),
     Image.asset("images/support.png")
  ];

   List<IconModel> Iconss = [
  IconModel(
 name: "Mobile", image: "images/website.png"),
  IconModel(
  name: "Mobile Payment", image: "images/Email.png"),
  IconModel(
  name: "Mobile Payment", image: "images/Facebook-256.png"),
  IconModel(
  name: "Mobile Payment", image: "images/Twitter-Bird-256.png"),
   IconModel(
  name: "Mobile Payment", image: "images/Instagram-256.png"),
   IconModel(
  name: "Mobile Payment", image: "images/YouTube1-256.png"),
   IconModel(
  name: "Mobile Payment", image: "images/LinkedIn.png"),
  IconModel(
  name: "Mobile Payment", image: "images/callcenter.png")];

  @override
  Widget build(BuildContext context) {
    dateController.text = dateTime;
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: const Color(0xFF111111),
      appBar: AppBar(
        backgroundColor: const Color(0xFF3A3A3A),
        title: const Text(
          "Feedback",
          style: TextStyle(color: Color(0xFFFFAE00)),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Color(0xFFFFAE00),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: IconButton(
                onPressed: () {
            //     Fluttertoast.showToast(msg: "sss");
           //      shareapp();
              //   Share.share('http://165.22.219.135/genie_money/apk/geniemoney.apk');
                 Share.share('Download the GenieMoney From Below Link ttps://tinyurl.com/4vhf5udx');



                }, icon: Image.asset("images/share.png",width: 20,height: 20,)),
          )
        ],
      ),
      body: Column(
        children: [
/*          Expanded(
            flex: 1,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Center(
                    child: Text(
                      'Customer Feedback',
                      textScaleFactor: 2,
                      style: TextStyle(color: Color(0xFFFFAE00)),
                    )),
              ],
            ),
          )*/
          Expanded(
            flex: 4,
            child: SingleChildScrollView(
              child: Container(
                padding: const EdgeInsets.all(10),
                width: 400,
                // height: 100,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: const Color(0xFF3A3A3A)),
                child: Column(
                  children: [
                    // For Showing Current Date and time
                    Container(
                      margin:EdgeInsets.only(top: 20),
                      child: TextField(

                        style: const TextStyle(color: Color(0xFFFFAE00)),
                        controller: dateController,
                        readOnly: true,
                        decoration: InputDecoration(
                            labelText: "Date & Time",
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                              const BorderSide(color: Color(0xFFFFAE00)),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                              const BorderSide(color: Color(0xFFFFAE00)),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            labelStyle: const TextStyle(color: Colors.amber)),
                        keyboardType: TextInputType.text,
                      ),
                    ),

                    // For Title
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: TextField(
                        style: const TextStyle(color: Color(0xFFFFAE00)),
                        controller: titleController,
                        decoration: InputDecoration(
                            hintStyle: const TextStyle(color: Color(0xFFFFAE00)),
                            hintText: 'Title',
                            // labelText: "Title",
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                              const BorderSide(color: Color(0xFFFFAE00)),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                              const BorderSide(color: Color(0xFFFFAE00)),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            labelStyle: const TextStyle(color: Colors.amber)),
                        keyboardType: TextInputType.text,
                      ),
                    ),

                    const SizedBox(height: 20),
                    // For Message Description
                    TextField(
                      maxLines: 7,
                      cursorColor: const Color(0xFFFFAE00),
                      style: const TextStyle(color: Color(0xFFFFAE00)),
                      controller: descriptionController,
                      decoration: InputDecoration(
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                          const BorderSide(color: Color(0xFFFFAE00)),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderSide:
                          const BorderSide(color: Color(0xFFFFAE00)),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                          const BorderSide(color: Color(0xFFFFAE00)),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        border: OutlineInputBorder(
                          borderSide:
                          const BorderSide(color: Color(0xFFFFAE00)),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                        hintText: 'Description',
                        hintStyle: const TextStyle(color: Color(0xFFFFAE00)),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 15),
                    //Material Button for submission
                    MaterialButton(
                      minWidth: width * 0.622,
                      shape: const RoundedRectangleBorder(
                          borderRadius:
                          BorderRadius.all(Radius.circular(20.0))),
                      color: Colors.amber,
                      onPressed: () {
                        sendFeedBack();

                      },
                      child: const Text('Submit'),
                    ),
                    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: const Color(0xFF3A3A3A)),
                            height: 130,
                            width: 396,
                            child: Column(
                              children: [
                                SizedBox(
                                  height: 60,
                                  child: Padding(
                                    padding: const EdgeInsets.only(top: 8.0),
                                    child: GridView.builder(
                                      gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                        mainAxisSpacing: 0,
                                        crossAxisSpacing: 1,
                                        crossAxisCount: 7,
                                      ),
                                      // shrinkWrap: true,
                                      itemCount: Iconss.length,
                                      itemBuilder: (context, index) {
                                        var iconIndex = Iconss[index];
                                        return SingleChildScrollView(
                                          child: Container(
                                            height: 200,
                                            width: 200,
                                            // color: Colors.grey,
                                            padding: const EdgeInsets.only(top: 0),
                                            decoration: const BoxDecoration(
                                              // color: Colors.transparent,
                                                shape: BoxShape.circle),
                                            child: Column(
                                              children: [
                                                IconButton(
                                                    onPressed: () {
                                                      iconIndex.name=="Mobile"?_launchURL(): print("clicke"+icons[0].toString());

                                                    },
                                                    icon: Image.asset(iconIndex.image)),
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
/*
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    IconButton(
                                        onPressed: () {},
                                        icon: Image.asset('images/callcenter.png')),
                                    const Text(
                                      '1800 120 999 333',
                                      textScaleFactor: 2,
                                      style: TextStyle(color: Color(0xFFFFAE00)),
                                    )
                                  ],
                                ),
*/
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),

                  ],
                ),
              ),
            ),
          ),
          // For ListViewBuilder Items
        ],
      ),
    );
  }

  _launchURL() async{
    const url = 'http://geniemoney.in/';
    if (await canLaunch(url)) {
    await launch(url);
    } else {
    throw 'Could not launch $url';
    }
  }

  Future<void> sendFeedBack() async {

    if(titleController.text.isEmpty){
      Fluttertoast.showToast(
          msg: "Please Enter Title",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }

    else if(descriptionController.text.isEmpty){

      Fluttertoast.showToast(
          msg: "Please Enter Description",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);

    }
    else{
      Map<String, String> jsonbody = {
        "userid":Constants.userid,
        "phone":Constants.phone,

        "admin_type":Constants.admin_type,
        "email":Constants.email,
        // "user_id:": user.toString(),
        "title": titleController.text.toString(),

        "description": descriptionController.text.toString(),

      };
      var network = NewVendorApiService();

      String urls =
          "http://165.22.219.135/genie_money/public/index.php/feedbacksave";
      var res = await network.postresponse(urls, jsonbody);
      var model = FeedBackResponseModel.fromJson(res);
      String stat = model.status.toString();

      if (model.status == 201) {
        Fluttertoast.showToast(
            msg: "FeedBack Added Succesfully  ",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
        titleController.clear();
        descriptionController.clear();

      }
      else {
        Fluttertoast.showToast(
            msg: "Somthing Went Wrong",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      }
     print("" + res!.toString());
     print("vvvvvvvvvvvvv" + Constants.userid.toString());

    }

  }
  Future<void> getuserid() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    setState((){
      user = sharedPreferences.getString('id')??"";
      print("lalalalala"+user.toString());
    });

  }

 /* Future<void> shareapp() async {
    await FlutterShare.share(
        title: 'Genie Money',
        text: 'Download the GenieMoney From Below Link',
        linkUrl: 'https://tinyurl.com/4vhf5udx',
        chooserTitle: 'Download the GenieMoney From Below Link'
    );
  }*/
}