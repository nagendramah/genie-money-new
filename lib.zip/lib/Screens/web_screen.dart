import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebIntent extends StatefulWidget {
  const WebIntent({Key? key}) : super(key: key);

  @override
  State<WebIntent> createState() => _WebIntentState();
}

class _WebIntentState extends State<WebIntent> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF3A3A3A),
        title: const Text(
          "Backend Dashboard",
          style: TextStyle(
            color: Color(0xFFFFAE00),
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Color(0xFFFFAE00),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      // body: WebView(
      //   javascriptMode: JavascriptMode.unrestricted,
      //   initialUrl: "http://165.22.219.135/genie_money/index.php/dashboard",
      // ),
    );
  }

  @override
  void initState() {
/*
_launchURRL();
*/
  }

  _launchURRL() async {
    const url = 'http://165.22.219.135/genie_money/index.php/dashboard';
    if (await canLaunch(url)) {
      await launch(url, enableJavaScript: true, forceWebView: true);
    } else {
      throw 'Could not launch $url';
    }
  }
}
