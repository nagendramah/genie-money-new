
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../Model/BrokerResponseModel.dart';
import '../Model/LeadGenModel.dart';
import '../Model/PaySprintCardLeadGenModel.dart';
import '../data/remote/network/ApiEndPointsPaySprint.dart';
import '../data/remote/network/NetworkApiServiceNewVendor.dart';
import '../data/remote/network/NetworkApiServicePaySprint.dart';
import '../utils/constants.dart';


class CreditCardLeadGeneration extends StatefulWidget {
  final String bankname,leadtype,account;
  const CreditCardLeadGeneration({Key? key, required this.bankname, required this.leadtype,required this.account}) : super(key: key);

  //CreditCardLeadGeneration( {Key? key,required this.bankname}) : super(key: key);

  @override
  State<CreditCardLeadGeneration> createState() => _CreditCardLeadGenerationState();
}
var appPassword;
late List<String> brokers;

/*@override
void initState() {

  String gtwayname="geniemoney";
  bool leprechaunMode = false;

  ScgatewayFlutterPlugin.setConfigEnvironment(GatewayEnvironment.PRODUCTION, gtwayname, leprechaunMode, brokers);


  brokers = [
    "fivepaisa",
    "iifl",
    "kite",
    "kotak"

  ];
}*/


class _CreditCardLeadGenerationState extends State<CreditCardLeadGeneration> {
  TextEditingController _name = TextEditingController();
  TextEditingController _phone = TextEditingController();
  TextEditingController _email = TextEditingController();
  TextEditingController _pincode = TextEditingController();
  TextEditingController _Address = TextEditingController();
  TextEditingController _state = TextEditingController();
  TextEditingController _Landmark = TextEditingController();

  String CustomerType = "Partner";
  var code;

  late String selected_type = "Customer Type";
  bool isProgessBarVisible = false;

  bool is_mobile_linked_aadhar = true;

  List<String> business_type_list = [
    'Customer Type',
    'SALARIED',
    'BUSINESSMAN'
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF111111),
      appBar: AppBar(
        backgroundColor: const Color(0xFF3A3A3A),
        title:  Text(
          widget.bankname.toString(),
          style: TextStyle(
            color: Color(0xFFFFAE00),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: const Color(0xFFFFAE00),
          onPressed: () {
            /*  Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          Home()));*/
            Navigator.of(context).pop();
          },
        ),

      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(10),
              child: TextFormField(
                  controller: _name,
                  //controller: _email_mobile_controller,
                  style: const TextStyle(color: Color(0xFFFFAE00)),
                  cursorColor: const Color(0xFFFFAE00),
                  keyboardType: TextInputType.text,
                  //controller: _email_controller,
                  decoration: InputDecoration(
                    counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    border: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                    // hintText: 'Email / Mobile No.',
                    labelText: 'Name',
                    isDense: true,
                  )),
            ),
            Container(
              width: 500,
              margin: EdgeInsets.all(10),
              child: Text(" My Mobile Is Linked With Aadhar",style: TextStyle(
                fontSize: 20,color: Color(0xFFFFAE00)
              ),
              textAlign: TextAlign.left,),
            ),

            Row(
mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Radio(
                      value: "yes",
                      groupValue: CustomerType,
                      activeColor: Color(0xFFFFAE00),
                      onChanged: (value) {
                        setState(() {
                          CustomerType = value.toString();

                          is_mobile_linked_aadhar = true;
                        });
                      },
                    ),
                    Text(
                      'Yes',
                      style: TextStyle(color: Color(0xFFFFAE00),fontSize: 13),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Radio(
                      value: "No",
                      groupValue: CustomerType,
                      activeColor: Color(0xFFFFAE00),
                      onChanged: (value) {
                        setState(() {
                          is_mobile_linked_aadhar = true;

                          CustomerType = value.toString();
                        });
                      },
                    ),
                    Text(
                      'No',
                      style: TextStyle(color: Color(0xFFFFAE00),fontSize: 13),
                    ),

                  ],
                ),
              ],
            ),

            Container(
              margin: EdgeInsets.all(10),
              child: TextFormField(
                  controller: _phone
                  ,
                  //controller: _email_mobile_controller,
                  style: const TextStyle(color: Color(0xFFFFAE00)),
                  cursorColor: const Color(0xFFFFAE00),
                  keyboardType: TextInputType.text,
                  //controller: _email_controller,
                  decoration: InputDecoration(
                    counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    border: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                    // hintText: 'Email / Mobile No.',
                    labelText: 'Phone no',
                    isDense: true,
                  )),
            ),

            Container(
              margin: EdgeInsets.all(10),
              child: TextFormField(
                  controller: _email,
                  //controller: _email_mobile_controller,
                  style: const TextStyle(color: Color(0xFFFFAE00)),
                  cursorColor: const Color(0xFFFFAE00),
                  keyboardType: TextInputType.text,
                  //controller: _email_controller,
                  decoration: InputDecoration(
                    counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    border: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                    // hintText: 'Email / Mobile No.',
                    labelText: 'Email',
                    isDense: true,
                  )),
            ),

            Container(
              margin: EdgeInsets.all(10),
              child:             Container(

                child: DropdownButtonFormField<String>(
                  dropdownColor: const Color(0xFF3A3A3A),
                  isExpanded: true,
                  decoration: const InputDecoration(
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.all(
                          Radius.circular(10.0)),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.all(
                          Radius.circular(10.0)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.all(
                          Radius.circular(10.0)),
                    ),
                    border: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.all(
                          Radius.circular(10.0)),
                    ),
                    isDense: true,
                  ),
                  value: selected_type,
                  icon: const Icon(
                    Icons.arrow_drop_down,
                    color: Color(0xFFFFAE00),
                  ),
                  iconSize: 24,
                  elevation: 16,
                  style: const TextStyle(
                      color: Color(0xFFFFAE00), fontSize: 18),
                  onChanged: (String? data) {
                    setState(() {
                      selected_type =
                          data ?? "Select Business Type";
                    });


                  },
                  items: business_type_list
                      .map<DropdownMenuItem<String>>(
                          (String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                ),
              ),

            ),


            Container(
              margin: EdgeInsets.all(10),
              child: TextFormField(
                  controller: _Address,
                  //controller: _email_mobile_controller,
                  style: const TextStyle(color: Color(0xFFFFAE00)),
                  cursorColor: const Color(0xFFFFAE00),
                  keyboardType: TextInputType.text,
                  //controller: _email_controller,
                  decoration: InputDecoration(
                    counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    border: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                    // hintText: 'Email / Mobile No.',
                    labelText: 'Address',
                    isDense: true,
                  )),
            ),
            Container(
              margin: EdgeInsets.all(10),
              child: TextFormField(
                  controller: _pincode,
                  //controller: _email_mobile_controller,
                  style: const TextStyle(color: Color(0xFFFFAE00)),
                  cursorColor: const Color(0xFFFFAE00),
                  keyboardType: TextInputType.text,
                  //controller: _email_controller,
                  decoration: InputDecoration(
                    counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    border: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                    // hintText: 'Email / Mobile No.',
                    labelText: 'Pincode',
                    isDense: true,
                  )),
            ),
            Container(
              margin: EdgeInsets.all(10),
              child: TextFormField(
                  controller: _Landmark,
                  //controller: _email_mobile_controller,
                  style: const TextStyle(color: Color(0xFFFFAE00)),
                  cursorColor: const Color(0xFFFFAE00),
                  keyboardType: TextInputType.text,
                  //controller: _email_controller,
                  decoration: InputDecoration(
                    counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    border: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                    // hintText: 'Email / Mobile No.',
                    labelText: 'Landmark',
                    isDense: true,
                  )),
            ),
            Container(
              margin: EdgeInsets.all(10),
              child: TextFormField(
                  controller: _state,
                  //controller: _email_mobile_controller,
                  style: const TextStyle(color: Color(0xFFFFAE00)),
                  cursorColor: const Color(0xFFFFAE00),
                  keyboardType: TextInputType.text,
                  //controller: _email_controller,
                  decoration: InputDecoration(
                    counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    border: OutlineInputBorder(
                      borderSide:
                      const BorderSide(color: Color(0xFFFFAE00)),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                    // hintText: 'Email / Mobile No.',
                    labelText: 'State',
                    isDense: true,
                  )),
            ),



            Container(
              height: 40,
              margin: EdgeInsets.all(10),
              child: Center(
                child: ElevatedButton(
                  onPressed: () {
                    if(_name.text.isEmpty)
                    {
                      Fluttertoast.showToast(
                          msg: "Please enter name",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.CENTER,
                          timeInSecForIosWeb: 1,
                          backgroundColor: Colors.red,
                          textColor: Colors.white,
                          fontSize: 16.0);
                    }
                    else if(_email.text.isEmpty)
                    {
                      Fluttertoast.showToast(
                          msg: "Please enter email",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.CENTER,
                          timeInSecForIosWeb: 1,
                          backgroundColor: Colors.red,
                          textColor: Colors.white,
                          fontSize: 16.0);
                    }
                    else  if(_phone.text.isEmpty)
                    {
                      Fluttertoast.showToast(
                          msg: "Please enter phone no",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.CENTER,
                          timeInSecForIosWeb: 1,
                          backgroundColor: Colors.red,
                          textColor: Colors.white,
                          fontSize: 16.0);
                    }
                    else  if(_pincode.text.isEmpty)
                    {
                      Fluttertoast.showToast(
                          msg: "Please enter pincode",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.CENTER,
                          timeInSecForIosWeb: 1,
                          backgroundColor: Colors.red,
                          textColor: Colors.white,
                          fontSize: 16.0);
                    }
                    else
                    {
                      if(widget.leadtype=="credit card")
                        {
                          CardLeaddata();
                          BackendCardLeaddata();

                        }
                      else{
                        Personalloandleaddata();
                        BackendPersonalloandleaddata();

                      }

                      // getdata();
                      // //  ScgatewayFlutterPlugin.initGateway(authToken);
                      //
                      // ScgatewayFlutterPlugin.leadGen(_name.text, _email.text, _phone.text, _pincode.text);
                      // //   ScgatewayFlutterPlugin.leadGenWithStatus(_name.text, _email.text, _phone.text);
                      // getpass();

                      // Fluttertoast.showToast(
                      //     msg: "Success",
                      //     toastLength: Toast.LENGTH_SHORT,
                      //     gravity: ToastGravity.CENTER,
                      //     timeInSecForIosWeb: 1,
                      //     backgroundColor: Colors.green,
                      //     textColor: Colors.white,
                      //     fontSize: 16.0);
                      //  if(_pincode.text.isNotEmpty)
                      //    {
                      //      if (widget.bankname.toString() == "5Pasia") {
                      //        _launchURL("https://www.5paisa.com/landing/open-demat-online");
                      //
                      //
                      //      }
                      //      else   if (widget.bankname.toString()  == "Kotak Securities") {
                      //        _launchURL("https://www.kotaksecurities.com/open-demat-account/");
                      //      }
                      //
                      //      else if (widget.bankname.toString()== "IIFL") {
                      //        _launchURL("https://www.indiainfoline.com/open-demat-account");
                      //      }
                      //      else {
                      // //       _launchURL("https://zerodha.com/open-account");
                      //        _launchURL("https://zerodha.com/open-account");
                      //
                      //
                      //      }
                      //    }
                    }
                    // _launchURL();

                    // Navigator.pop(context);
                    //             Navigator.push(context, MaterialPageRoute(builder: context) => VendorPaymentPage));


                  },
                  child: Text(
                    "Submit",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.bold),
                  ),
                  style: ElevatedButton.styleFrom(
                    //fixedSize: Size(width, MediaQuery.of(context).size.height * 0.05),
                    primary: const Color(0xFFFFAE00),
                    shadowColor: const Color(0xFFFFAE00),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                  ),
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    var rng = new Random();
    code = rng.nextInt(900000) + 100000;
    postdata();
  }


  _launchURL(String s) async{
    var url = s;
    if (url.isNotEmpty) {
      launchUrl(Uri.parse(url),mode:LaunchMode.externalApplication);
    } else {
      throw 'Could not launch $url';
    }
  }

  Future<void> getpass() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    appPassword = prefs.getString("leadgen")??"";
  }

  Future<void> getdata() async {
    Map<String, String> jsonbody = {
      "bank_name": widget.bankname.toString(),
      "name":_name.text.toString(),
      "email":_email.text.toString(),
      "phone":_phone.text.toString(),
      "pincode":_pincode.text.toString(),
      "user_id": Constants.userid.toString(),

    };
    var network = NewVendorApiService();
    String urls =
        "http://165.22.219.135/genie_money/index.php/saveDemateAccount";
    var res = await network.postresponse(urls, jsonbody);
    var model = BrokerResponseModel.fromJson(res);
    print("ApiResponse"+res.toString());
    String stat = model.status.toString();
    String msg = model.messages!.success.toString();
    if (stat.toString().contains("201")) {
      Fluttertoast.showToast(
          msg: msg,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      if (widget.bankname.toString() == "5Pasia") {
        _launchURL("https://www.5paisa.com/landing/open-demat-online");
      }
      else   if (widget.bankname.toString()  == "Kotak Securities") {
        _launchURL("https://www.kotaksecurities.com/open-demat-account/");
      }

      else if (widget.bankname.toString()== "IIFL") {
        _launchURL("https://www.indiainfoline.com/open-demat-account");
      }
      else {
        //       _launchURL("https://zerodha.com/open-account");
        _launchURL("https://zerodha.com/open-account");
      }
    }
    else {
      Fluttertoast.showToast(
          msg: "Somthing Went Wrong",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }

  }


  Future<void> CardLeaddata() async {
    try{
      loadProgress();
      var network =  NetworkApiServicePaySprint();

      Map<String, String> x =  {
        "address": _Address.text,
        "pinCode": _pincode.text,
        "landMark": _Landmark.text
      };
      Map<String,String> jsonbody = {
        "current_address": x.toString(),
        "merchantcode": "A002",
        "refid": code.toString(),
        "name": _name.text,
        "mobile_no": _phone.text,
        "state": _state.text,
        "customer_type": selected_type,
        "email": _email.text,
        "is_mobile_linked_aadhar": is_mobile_linked_aadhar.toString(),


      };
      var res = await network.postResponse(ApiEndPointsPaySprint().CreditCardLead, jsonbody);
      print(res);
      print("credit card");

      Map<String, dynamic> jsonres = res;
      var model = PaySprintCardLeadGenModel.fromJson(jsonres);
      var ee = model.status.toString();
      if(ee!=true){

        Fluttertoast.showToast(
            msg: model.message.toString(),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);

      }
      else {
        print("ssss"+ee);

        Fluttertoast.showToast(
            msg: "Transaction Successfully Added",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);

      }
      
    
      loadProgress();
    }catch(e){
      loadProgress();
      print(e);
    }

  }

  loadProgress(){
    if(isProgessBarVisible == true){
      setState(() {
        isProgessBarVisible = false;
      });
    }
    else{
      setState(() {
        isProgessBarVisible = true;
      });
    }

  }

  Future<void> Personalloandleaddata() async {
    try{
      loadProgress();
      var network =  NetworkApiServicePaySprint();

      Map<String, String> x =  {
        "address": _Address.text,
        "pinCode": _pincode.text,
        "landMark": _Landmark.text
      };
      Map<String,String> jsonbody = {
        "current_address": x.toString(),
        "merchantcode": "A002",
        "refid": code.toString(),
        "name": _name.text,
        "mobile_no": _phone.text,
        "state": _state.text,
        "customer_type": selected_type,
        "email": _email.text,
        "is_mobile_linked_aadhar": is_mobile_linked_aadhar.toString(),


      };
      var res = await network.postResponse(ApiEndPointsPaySprint().personalloan, jsonbody);
      print(res);
      print("Personal loan");
      Map<String, dynamic> jsonres = res;
      // var model = BeneficiaryListModel.fromJson(jsonres);
      // if(model.status){
      //   setState(() {
      //     beneficiaryList = model.data;
      //   });
      // }
      // setState(() {
      //   beneficiaVisibility = true;
      // });
      loadProgress();
    }catch(e){
      loadProgress();
      print(e);
    }
  }

  Future<void> BackendCardLeaddata() async {
    Map<String, String> jsonbody = {
      "service_type":"tradition_credit_card",
      "type":Constants.type,

      "bank_name":widget.bankname.toString(),
      "name":_name.text,
      "phone":_phone.text,
      "customer_type":selected_type,
      "address":_Address.text,
      "pincode":_pincode.text,
      "landmark":_Landmark.text,
      "state":_state.text,
      "link_adhar":_state.text,
      // "user_id:": user.toString(),

    };

    var network = NewVendorApiService();

    String urls =
        "http://165.22.219.135/genie_money/index.php/loanservices";
    var res = await network.postresponse(urls, jsonbody);
    var model = LeadGenModel.fromJson(res);
    String stat = model.status.toString();

    if (model.status == 201) {
      Fluttertoast.showToast(
          msg: "Transaction Successfully Added",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);

      Navigator.pop(context);

    }
    else {
      Fluttertoast.showToast(
          msg: "Somthing Went Wrong",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
    print("" + res!.toString());
    print("vvvvvvvvvvvvv" + Constants.userid.toString());

  }

  Future<void> BackendPersonalloandleaddata() async {
    Map<String, String> jsonbody = {
      "service_type":"tradition_personal_loan",
      "type":Constants.type,

      "bank_name":widget.bankname.toString(),
      "name":_name.text,
      "phone":_phone.text,
      "customer_type":selected_type,
      "address":_Address.text,
      "pincode":_pincode.text,
      "landmark":_Landmark.text,
      "state":_state.text,
      "link_adhar":_state.text,
      // "user_id:": user.toString(),

    };

    var network = NewVendorApiService();

    String urls =
        "http://165.22.219.135/genie_money/index.php/loanservices";
    var res = await network.postresponse(urls, jsonbody);
    var model = LeadGenModel.fromJson(res);
    String stat = model.status.toString();

    if (model.status == 201) {
      Fluttertoast.showToast(
          msg: "Transaction Successfully Added",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      Navigator.pop(context);
    }
    else {
      Fluttertoast.showToast(
          msg: "Somthing Went Wrong",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
    print("" + res!.toString());
    print("vvvvvvvvvvvvv" + Constants.userid.toString());

  }


  Future<void> postdata() async {
    final url = Uri.parse("http://165.22.219.135/genie_money/index.php/Traditional_Bank");
    final response = await http.post(url, body: {
      "id":"521",
      "name":_name.text,
      "linked_adhar":CustomerType,
      'phone_no':_phone.text,
      "email":Constants.email,
      'customer_type':selected_type,
      "address":_Address.text,
      'pincode':_pincode.text,
      "bank_name":widget.bankname.toString(),
      "type":widget.account.toString(),});
    print(response.body);
    if (response.statusCode == 201) {
      setState(() {
      });
      print("object");
      print("jankiii lolllllllgdhgfghdfgfdgfgfd");
    } else {
      print('something worng');
      print("janki javoooooooooooooooooooo");
    }
  }

}
