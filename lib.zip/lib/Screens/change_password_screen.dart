import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Model/ChangePasswordModel.dart';
import '../data/remote/network/NetworkApiServiceNewVendor.dart';
import '../utils/constants.dart';
import 'package:genie_money/utils/constants.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({Key? key}) : super(key: key);

  @override
  State<ChangePassword> createState() => _ChangePasswordState();

}

class _ChangePasswordState extends State<ChangePassword> {
  @override
  _savebool() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
await prefs.setBool("lock", isToggle);
  }

  TextEditingController _Password = TextEditingController();
  TextEditingController _newPassword = TextEditingController();
  TextEditingController _appPassword = TextEditingController();
  TextEditingController _comfirmAPassword = TextEditingController();
  bool isToggle = false;
  bool showPermanentAddress = false;

  bool _passwordVisible=true;
  var sharePassword;


  @override
  void initState() {
    _passwordVisible = false;
loadData();
    getpass();
    super.initState();

  }

  loadData()async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
setState(() {
  isToggle = prefs.getBool("lock")!;
});
  }


  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: const Color(0xFF111111),

      appBar: AppBar(
        backgroundColor: const Color(0xFF3A3A3A),
        title: const Text(
          "Change Password",
          style: TextStyle(
            color: Color(0xFFFFAE00),
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Color(0xFFFFAE00),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),

      body: SingleChildScrollView(
        child: Container(

          child: Column(
            children: [
              Card(
                color: const Color(0xFF2A2A2A),

                child: Padding(

                  padding: EdgeInsets.only(
                      top: 10.0, left: 6.0, right: 6.0, bottom: 6.0),
                  child: ExpansionTile(
                    title: Text('Enable Default Lock For Genie Money ',style: TextStyle(
                        color: const Color(0xFFFFAE00)
                    ),),
                    trailing: Icon(
                      Icons.keyboard_arrow_down,
                      color: Color(0xFFFFAE00),
                    ),
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.all(10),

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              children: [
                                const Text(
                                  "Enable Default Lock",
                                  style: TextStyle(
                                      color: Color(0xFFFFAE00), fontSize: 18.0),
                                  textAlign: TextAlign.left,
                                ),
                              ],
                            ),
                            FlutterSwitch(
                              activeColor: const Color(0xFFFFAE00),
                              width: width * 0.15,
                              height: height * 0.05,
                              toggleSize: 25.0,
                              value: isToggle,
                              borderRadius: 15.0,
                              onToggle: (val) {
                                setState(() {

                                  isToggle = val;
                                  _savebool();
                                });
                              },
                            ),
                          ],
                        ),
                      ),




                    ],
                  ),
                ),
              ),


              Card(
                color: const Color(0xFF2A2A2A),

                child: Padding(
                  padding: EdgeInsets.only(
                      top: 10.0, left: 6.0, right: 6.0, bottom: 6.0),
                  child: ExpansionTile(
                    title: Text('Set Login Password',style: TextStyle(
                        color: const Color(0xFFFFAE00)
                    ),),
                    trailing: Icon(
                      Icons.keyboard_arrow_down,
                      color: Color(0xFFFFAE00),
                    ),
                    children: <Widget>[
                      Container(

                        margin: EdgeInsets.all(10),
                        child: TextField(
                            obscureText: _passwordVisible,

                            controller: _Password,
                            //controller: _email_mobile_controller,
                            style: const TextStyle(color: Color(0xFFFFAE00)),
                            cursorColor: const Color(0xFFFFAE00),
                            keyboardType: TextInputType.text,
                            //controller: _email_controller,
                            decoration: InputDecoration(
                              counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                              focusedBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              disabledBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              border: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                              // hintText: 'Email / Mobile No.',
                              labelText: 'Password',
                              isDense: true,
                              suffixIcon: IconButton(onPressed: () {
                                setState(() {
                                  _passwordVisible = !_passwordVisible;
                                });
                              }, icon:  Icon(
                                // Based on passwordVisible state choose the icon
                                _passwordVisible
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                                color: Color(0xFFFFAE00),
                              ),),

                            )),
                      ),
                      Container(
                        margin: EdgeInsets.all(10),
                        child: TextFormField(
                            obscureText: _passwordVisible,

                            controller: _newPassword,
                            //controller: _email_mobile_controller,
                            style: const TextStyle(color: Color(0xFFFFAE00)),
                            cursorColor: const Color(0xFFFFAE00),
                            keyboardType: TextInputType.text,
                            //controller: _email_controller,
                            decoration: InputDecoration(
                              counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                              focusedBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              disabledBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              border: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                              // hintText: 'Email / Mobile No.',
                              labelText: 'Confirm Password',
                              isDense: true,
                              suffixIcon: IconButton(onPressed: () {
                                setState(() {
                                  _passwordVisible = !_passwordVisible;
                                });
                              }, icon:  Icon(
                                // Based on passwordVisible state choose the icon
                                _passwordVisible
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                                color: Color(0xFFFFAE00),
                              ),),

                            )),
                      ),

                      Container(
                        height: 40,
                        margin: EdgeInsets.all(10),
                        child: Center(
                          child: ElevatedButton(
                            onPressed: () {
                              //Navigator.pop(context);
                              setState(() {
                                changepass();
                               // Navigator.of(context).pop();
                              });
                            },
                            child: Text(
                              "Submit",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold),
                            ),
                            style: ElevatedButton.styleFrom(
                              //fixedSize: Size(width, MediaQuery.of(context).size.height * 0.05),
                              primary: const Color(0xFFFFAE00),
                              shadowColor: const Color(0xFFFFAE00),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                          ),
                        ),
                      ),




                    ],
                  ),
                ),
              ),


              Card(
                color: const Color(0xFF2A2A2A),

                child: Padding(
                  padding: EdgeInsets.only(
                      top: 10.0, left: 6.0, right: 6.0, bottom: 6.0),
                  child: ExpansionTile(
                    title: Text('Set Password for Genie Money App',style: TextStyle(
                        color: const Color(0xFFFFAE00)
                    ),),
                    trailing: Icon(
                      Icons.keyboard_arrow_down,
                      color: Color(0xFFFFAE00),
                    ),
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.all(10),
                        child: TextFormField(
                            obscureText: _passwordVisible,

                            controller: _appPassword,
                            //controller: _email_mobile_controller,
                            style: const TextStyle(color: Color(0xFFFFAE00)),
                            cursorColor: const Color(0xFFFFAE00),
                            keyboardType: TextInputType.text,
                            //controller: _email_controller,
                            decoration: InputDecoration(
                              counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                              focusedBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              disabledBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              border: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                              // hintText: 'Email / Mobile No.',
                              labelText: 'Password',
                              isDense: true,
                              suffixIcon: IconButton(onPressed: () {
                                setState(() {
                                  _passwordVisible = !_passwordVisible;
                                });
                              }, icon:  Icon(
                                // Based on passwordVisible state choose the icon
                                _passwordVisible
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                                color: Color(0xFFFFAE00),
                              ),),

                            )),
                      ),
                      Container(
                        margin: EdgeInsets.all(10),
                        child: TextFormField(
                            obscureText: _passwordVisible,

                            controller: _comfirmAPassword,
                            //controller: _email_mobile_controller,
                            style: const TextStyle(color: Color(0xFFFFAE00)),
                            cursorColor: const Color(0xFFFFAE00),
                            keyboardType: TextInputType.text,
                            //controller: _email_controller,
                            decoration: InputDecoration(
                              counterStyle: TextStyle(color: Color(0xFFFFAE00)),
                              focusedBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              disabledBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              border: OutlineInputBorder(
                                borderSide:
                                const BorderSide(color: Color(0xFFFFAE00)),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              labelStyle: const TextStyle(color: Color(0xFFFFAE00)),
                              // hintText: 'Email / Mobile No.',
                              labelText: 'Confirm Password',
                              isDense: true,
                              suffixIcon: IconButton(onPressed: () {
                                setState(() {
                                  _passwordVisible = !_passwordVisible;
                                });
                              }, icon:  Icon(
                                // Based on passwordVisible state choose the icon
                                _passwordVisible
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                                color: Color(0xFFFFAE00),
                              ),),

                            )),
                      ),

                      Container(
                        height: 40,
                        margin: EdgeInsets.all(10),
                        child: Center(
                          child: ElevatedButton(
                            onPressed: () {
                              //Navigator.pop(context);
                              setState(() async {
                                if(_appPassword.text.isEmpty||_comfirmAPassword.text.isEmpty){
                                  SharedPreferences prefs = await SharedPreferences.getInstance();
                                  // Constants.changeloginpass = _Password.text;
                                  // Constants.confirmchangeloginpass = _newPassword.text;
                                  // Constants.apppass = _appPassword.text;
                                  // Constants.confirmapppass = _comfirmAPassword.text;
                                  // await prefs.setBool('isLoggedIn', true);
                                  await prefs.setString("apppass", "1");
                                  await prefs.setString("confirmapppass", _comfirmAPassword.text);                                    Navigator.of(context).pop();
                                  Navigator.of(context).pop();


                                }
                                else
                                  {
                                    SharedPreferences prefs = await SharedPreferences.getInstance();
                                    await prefs.setString("apppass", _appPassword.text);
                                    await prefs.setString("confirmapppass", _comfirmAPassword.text);
                                    Navigator.of(context).pop();
                                  }
                                  // if (_appPassword.text.isEmpty){
                                  //   et= "1";
                                  //   SharedPreferences prefs = await SharedPreferences.getInstance();
                                  //   Constants.apppass = et.toString();
                                  //
                                  //   await prefs.setString("apppass", Constants.apppass);
                                  //   Navigator.of(context).pop();
                                  //
                                  // }
                                  // else{
                                    // Constants.changeloginpass = _Password.text;
                                    // Constants.confirmchangeloginpass = _newPassword.text;
                                    // Constants.apppass = _appPassword.text;
                                    // Constants.confirmapppass = _comfirmAPassword.text;
                                    // await prefs.setBool('isLoggedIn', true);



                                // SharedPreferences pref = await SharedPreferences.getInstance();
                                // var mobilenumber = pref.getString("mobileNumber")??"";
                                // var benefId = widget.benefid;
                                // var isdel = await deletedBeneficiary(mobilenumber,benefId);
                              });
                            },
                            child: Text(
                              "Submit",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold),
                            ),
                            style: ElevatedButton.styleFrom(
                              //fixedSize: Size(width, MediaQuery.of(context).size.height * 0.05),
                              primary: const Color(0xFFFFAE00),
                              shadowColor: const Color(0xFFFFAE00),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                          ),
                        ),
                      ),




                    ],
                  ),
                ),
              ),



            ],
          ),
        ),
      ),

    );
  }

  Future<void> getpass() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    sharePassword = prefs.getString("apppass")??"";
    if(sharePassword.toString()=="1")
      {
        _appPassword.clear();
        _comfirmAPassword.clear();
      }
    else
      {
        _appPassword.text= sharePassword;
        _comfirmAPassword.text=sharePassword;

      }


  }

  Future<void> changepass() async {

    if(_newPassword.text==_Password.text){
      Map<String, String> jsonbody = {
        "userid": Constants.userid,
        "admin_type": Constants.type,
        //"cpass": _Password.text.toString(),

        "npass": _newPassword.text.toString(),

      };


      // "user_id:": user.toString(),

      //  "district": _DistrictController.text.toString(),



      var network = NewVendorApiService();
      String urls =
          "http://165.22.219.135/genie_money/public/index.php/passchange";
      var res = await network.postresponse(urls, jsonbody);
      print(res);
      var model = ChangePasswordModel.fromJson(res);
      String stat = model.status.toString();
      String? msg = model.messages?.error.toString();

      if(stat.toString().contains("201"))
      {
        Fluttertoast.showToast(
            msg: "Update Password successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);

      }
      else {
        Fluttertoast.showToast(
            msg: msg.toString(),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      }
    }

    else{
      Fluttertoast.showToast(
          msg: "Password do not match",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }

  }
}
