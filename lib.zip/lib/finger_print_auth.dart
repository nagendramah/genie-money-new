import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:genie_money/Screens/splash_screen.dart';
import 'package:local_auth/local_auth.dart';

class FingerprintAuth extends StatefulWidget {
  const FingerprintAuth({Key? key}) : super(key: key);

  @override
  _FingerprintAuthState createState() => _FingerprintAuthState();
}

class _FingerprintAuthState extends State<FingerprintAuth> {
  final LocalAuthentication auth = LocalAuthentication();
  _SupportState _supportState = _SupportState.unknown;
  bool? _canCheckBiometrics;
  List<BiometricType>? _availableBiometrics;
  String _authorized = 'Not Authorized';
  bool _isAuthenticating = false;
  bool showWeb = false;

  @override
  void initState() {
    _authenticate();
    super.initState();
    auth.isDeviceSupported().then(
          (bool isSupported) => setState(() => _supportState = isSupported
              ? _SupportState.supported
              : _SupportState.unsupported),
        );
  }

  Future<void> _checkBiometrics() async {
    late bool canCheckBiometrics;
    try {
      canCheckBiometrics = await auth.canCheckBiometrics;
    } on PlatformException catch (e) {
      canCheckBiometrics = false;
      print(e);
    }
    if (!mounted) {
      return;
    }

    setState(() {
      _canCheckBiometrics = canCheckBiometrics;
    });
  }

  Future<void> _getAvailableBiometrics() async {
    late List<BiometricType> availableBiometrics;
    try {
      availableBiometrics = await auth.getAvailableBiometrics();
    } on PlatformException catch (e) {
      availableBiometrics = <BiometricType>[];
      print(e);
    }
    if (!mounted) {
      return;
    }

    setState(() {
      _availableBiometrics = availableBiometrics;
    });
  }

  Future<void> _authenticate() async {
    bool authenticated = false;
    try {
      setState(() {
        _isAuthenticating = true;
        _authorized = 'Authenticating';
      });
      authenticated = await auth.authenticate(
        localizedReason:
            'For Genei Money Access : Unlock your screen with PIN, Pattern, Password, Face or Fingerprint.',
        options: const AuthenticationOptions(
          stickyAuth: true,
        ),
      );
      setState(() {
        _isAuthenticating = false;
      });
    } on PlatformException catch (e) {
      print(e);
      setState(() {
        _isAuthenticating = false;
        _authorized = 'Error - ${e.message}';
      });
      return;
    }

    if (!mounted) {
      return;
    }

    setState(
        () => _authorized = authenticated ? 'Authorized' : 'Not Authorized');
    if (_authorized == "Authorized") {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => SplashScreen()));
    } else {
      _alertDialog();
    }
  }

  Future<void> _authenticateWithBiometrics() async {
    bool authenticated = false;
    try {
      setState(() {
        _isAuthenticating = true;
        _authorized = 'Authenticating';
      });
      authenticated = await auth.authenticate(
        localizedReason:
            'Scan your fingerprint (or face or whatever) to authenticate',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: true,
        ),
      );
      setState(() {
        _isAuthenticating = false;
        _authorized = 'Authenticating';
      });
    } on PlatformException catch (e) {
      print(e);
      setState(() {
        _isAuthenticating = false;
        _authorized = 'Error - ${e.message}';
      });
      return;
    }
    if (!mounted) {
      return;
    }

    final String message = authenticated ? 'Authorized' : 'Not Authorized';
    setState(() {
      if (message == "Authorized") {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => SplashScreen()));
      }

      _authorized = message;
    });
  }

  Future<void> _cancelAuthentication() async {
    await auth.stopAuthentication();
    setState(() => _isAuthenticating = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(title: Text("Fingerprint Auth")),
      backgroundColor: Color(0xFF3C3E52),
      // appBar: AppBar(
      //   title: const Text('Plugin genie app'),
      // ),
      // body: ListView(
      //   padding: const EdgeInsets.only(top: 30),
      //   children: <Widget>[
      //     Column(
      //       mainAxisAlignment: MainAxisAlignment.center,
      //       children: <Widget>[
      //         if (_supportState == _SupportState.unknown)
      //           const CircularProgressIndicator()
      //         else if (_supportState == _SupportState.supported)
      //           const Text('This device is supported')
      //         else
      //           const Text('This device is not supported'),
      //         const Divider(height: 100),
      //         Text('Can check biometrics: $_canCheckBiometrics\n'),
      //         ElevatedButton(
      //           onPressed: _checkBiometrics,
      //           child: const Text('Check biometrics'),
      //         ),
      //         const Divider(height: 100),
      //         Text('Available biometrics: $_availableBiometrics\n'),
      //         ElevatedButton(
      //           onPressed: _getAvailableBiometrics,
      //           child: const Text('Get available biometrics'),
      //         ),
      //         const Divider(height: 100),
      //         Text('Current State: $_authorized\n'),
      //         if (_isAuthenticating)
      //           ElevatedButton(
      //             onPressed: _cancelAuthentication,
      //             child: Row(
      //               mainAxisSize: MainAxisSize.min,
      //               children: const <Widget>[
      //                 Text('Cancel Authentication'),
      //                 Icon(Icons.cancel),
      //               ],
      //             ),
      //           )
      //         else
      //           Column(
      //             children: <Widget>[
      //               ElevatedButton(
      //                 onPressed: _authenticate,
      //                 child: Row(
      //                   mainAxisSize: MainAxisSize.min,
      //                   children: const <Widget>[
      //                     Text('Authenticate'),
      //                     Icon(Icons.perm_device_information),
      //                   ],
      //                 ),
      //               ),
      //               ElevatedButton(
      //                 onPressed: _authenticateWithBiometrics,
      //                 child: Row(
      //                   mainAxisSize: MainAxisSize.min,
      //                   children: <Widget>[
      //                     Text(_isAuthenticating
      //                         ? 'Cancel'
      //                         : 'Authenticate: biometrics only'),
      //                     const Icon(Icons.fingerprint),
      //                   ],
      //                 ),
      //               ),
      //             ],
      //           ),
      //       ],
      //     ),
      //   ],
      // ),
    );
  }

  void _alertDialog() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            backgroundColor: Color(0xFF3A3A3A),
            content: Container(
              height: 100,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.only(
                      top: 12,
                    ),
                    child: Text(
                      "Genie Money is locked",
                      style: TextStyle(color: Color(0xFFFFAE00), fontSize: 18),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 20, bottom: 1),
                        height: 40,
                        width: 100,
                        child: ElevatedButton(
                            child: const Text(
                              "Cancel",
                              style: TextStyle(
                                  color: Color(0xFF111111),
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold),
                            ),
                            style: ElevatedButton.styleFrom(
                              fixedSize: Size(30, 80.0),
                              primary: const Color(0xFFFFAE00),
                              shadowColor: const Color(0xFFFFAE00),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                            ),
                            onPressed: () async {
                              SystemNavigator.pop();
                            }),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 20, bottom: 1),
                        height: 40,
                        width: 100,
                        child: ElevatedButton(
                          child: const Text(
                            "Unlock",
                            style: TextStyle(
                                color: Color(0xFF111111),
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold),
                          ),
                          style: ElevatedButton.styleFrom(
                            fixedSize: Size(30, 80.0),
                            primary: const Color(0xFFFFAE00),
                            shadowColor: const Color(0xFFFFAE00),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                          ),
                          onPressed: () async {
                            _authenticate();
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        });
  }

  Future<bool> _onBackPressed() async {
    // Your back press code here...
    if (showWeb) {
      setState(() {
        showWeb = false;
      });
      return false;
    } else {
      return true;
    }
  }
}

enum _SupportState {
  unknown,
  supported,
  unsupported,
}
