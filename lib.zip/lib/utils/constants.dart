class Constants {
  static String name = "";
  static String userid = "";
  static String email = "";
  static String phone = "";
  static String type = "";
  static String refer = "";
  static String point = "";
  static String admin_type = "";
  static String category = "";
  static String Lock = "";

  // static String changeloginpass = "";
  // static String confirmchangeloginpass = "";
  // static String apppass = "";
  // static String confirmapppass = "";


}