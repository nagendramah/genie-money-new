import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:genie_money/Screens/splash_screen.dart';
import 'package:genie_money/finger_print_auth.dart';
import 'package:genie_money/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'Screens/enter_password_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
      .then((value) => {
            runApp(
              MyApp(),
            ),
          });
}

class MyApp extends StatefulWidget {
  MyApp({Key? key}) : super(key: key);
  static const MaterialColor primaryBlack = MaterialColor(
    _blackPrimaryValue,
    <int, Color>{
      50: Color(0xFF111111),
      100: Color(0xFF111111),
      200: Color(0xFF111111),
      300: Color(0xFF111111),
      400: Color(0xFF111111),
      500: Color(_blackPrimaryValue),
      600: Color(0xFF111111),
      700: Color(0xFF111111),
      800: Color(0xFF111111),
      900: Color(0xFF111111),
    },
  );
  static const int _blackPrimaryValue = 0xFF111111;

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  var pass;
  late bool locked = false;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Genie Money',
        theme: ThemeData(
          primarySwatch: MyApp.primaryBlack,
          unselectedWidgetColor: const Color(0xFFFFAE00),
        ),
        home: locked == true ? FingerprintAuth() : SplashScreen()
        //   home: const FingerprintAuth(),
        //home:  FingerprintPage(),
        //   home:pass.toString()=="1"?SplashScreen():EnterPasswordScreen(),
        );
  }

  @override
  void initState() {
    setState(() {
      // loadData();
    });
    //   pass = Constants.apppass;
    super.initState();
  }

  Future<void> getpass() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    pass = prefs.getString("apppass") ?? "";
    print(pass.toString());
  }

  loadData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      locked = prefs.getBool("lock")!;
    });
  }
}
